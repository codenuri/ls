﻿#include <iostream>

template<typename T> void foo(T arg)
{

}

int main()
{
	foo(1);
	foo(3.4);

	foo(1, 3.4);
	foo(1, 3.4, 'A');
}
