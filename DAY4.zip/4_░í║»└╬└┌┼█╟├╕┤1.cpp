﻿// 가변인자 클래스 템플릿
template<typename T> class tuple 
{
};

int main()
{
	tuple<int> t1;
	tuple<int, int> t2;
	tuple<int, int, double> t3;
}
