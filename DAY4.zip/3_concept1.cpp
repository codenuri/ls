#include <print>
#include <vector>
#include <type_traits>
#include <iterator>


template<typename T>
void foo(const T& arg)
{
	bool b = std::is_pointer_v<T>;
	
	std::println("{}", b);
}

int main()
{
	std::vector<int> v{ 1,2,3 };

	foo(v);
}
