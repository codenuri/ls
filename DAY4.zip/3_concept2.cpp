#include <print>
#include <vector>
#include <type_traits>
#include <iterator>

template<typename T>
void foo(const T& a)
{
	std::cout << 
}


int main()
{
	int n = 0;
	std::vector<int> v{ 1,2,3 };

	foo(n);
	foo(v);
}
