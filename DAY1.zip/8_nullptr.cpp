// 8_nullptr - 29page

int main()
{
	// C++98 ����
	int  n1 = 0;
	int* p1 = 0;
}