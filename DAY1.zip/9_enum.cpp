// 9_enum - 32 page

void foo(int dayofaweek) {}

int main()
{
	foo(0);  
}





